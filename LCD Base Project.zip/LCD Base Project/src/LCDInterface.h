#include "stm32f4xx.h"
#include "stm32f4xx_conf.h"
#include "cc2500.h"


#define RX_PKT 0x01

void initializeWireless(void);